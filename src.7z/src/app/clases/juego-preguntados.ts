export class JuegoPreguntados {
    tema: string;
    pregunta :string;
    respuestas: string[];
    respuestaCorrecta: number;   
    gano: string;
    
  
    constructor(){
        this.gano= "undefined";
    }



  
}

import { Operator } from "rxjs";

export class JuegoAgilidad {
    public numeroUno : number;
    public Operador: string;
    public numeroDos: number;
    public gano: boolean;
    public resultado :number;
    
    constructor(){
       this.gano = false;
    }

    
}
